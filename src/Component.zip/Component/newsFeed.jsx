import React, { Component } from "react";

class Newsfeed extends Component {
	render() {
		return (
			<div className="heading text-align-center">
				{/* <h1>Latest Posts</h1> */}
			</div>
		);
	}
}
export default Newsfeed;
