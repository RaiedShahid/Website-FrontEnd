import React, { Component } from "react";

class Not_Found extends Component {
	render() {
		return (
			<div>
				<h1>Not Found</h1>
			</div>
		);
	}
}
export default Not_Found;
