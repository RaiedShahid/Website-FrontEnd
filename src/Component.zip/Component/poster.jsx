import React, { Component } from "react";
import msngp from "../images/missingperson.jpg";

class Poster extends Component {
	render() {
		return (
			<div className="">
				{/* <img src={msngp} style={{ textAlign: "center" }} className="post"></img> */}
			</div>
		);
	}
}
export default Poster;
