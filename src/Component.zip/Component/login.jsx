import React, { Component } from "react";

class Login extends Component {
	render() {
		return (
			<React.Fragment>
				<div className="login">
					<div
						style={{
							backgroundColor: "white",
							marginTop: "10%",
							marginBottom: "10%"
						}}
					>
						<h1>Login</h1>
					</div>
					<div className="login_inner">
						<form action="/action_page.php">
							<div className="form-group">
								<label htmlFor="email">Email address:</label>
								<input
									type="email"
									className="form-control"
									id="emaillogin"
								></input>
							</div>
							<div className="form-group">
								<label htmlFor="loginpwd">Password:</label>
								<input
									type="password"
									className="form-control"
									id="pwd"
								></input>
							</div>
							<div className="checkbox">
								<label>
									<input type="checkbox"></input> Remember me
								</label>
							</div>
							<button type="submit" className="btn btn-primary">
								LogIn
							</button>
						</form>
					</div>
				</div>
			</React.Fragment>
		);
	}
}
export default Login;
