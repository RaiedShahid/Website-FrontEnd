import React, { Component } from "react";
import NewFiltration from "./newFiltraion";
// import Cards from "./cards";
import GenericCard from "./genericCard";
import ListGroup from "./listGroup";
import { getGenres } from "../DataBase/fakeGenre";
import { getInfo } from "../DataBase/fakeDataBase";
import Pagination from "./Pagination";
import { paginateDate } from "./../utils/paginateData";
import Searchbox from "./searchBox";
import Navbar from "./navbar";
import ShowInformation from "./showInformation";

class Catalog extends Component {
	state = {
		genre: [],
		info: [],
		pageSize: 9,
		currentPage: 1,
		searchQuery: "	",
		selectedGenre: "ALL"
	};
	componentDidMount() {
		const genres = [{ _id: "", name: "ALL" }, ...getGenres()];
		this.setState({ genre: genres, info: getInfo() });
	}
	handleGenreSelect = genre => {
		this.setState({ selectedGenre: genre, searchQuery: "", currentPage: 1 });
	};

	handlePageChange = page => {
		this.setState({ currentPage: page });
	};

	handelSearch = query => {
		this.setState({ searchQuery: query, selectedGenre: null, currentPage: 1 });
	};

	getPagedData = () => {
		const {
			pageSize,
			currentPage,
			selectedGenre,
			searchQuery,
			info
		} = this.state;

		let filtered = info;
		if (searchQuery)
			filtered = info.filter(m =>
				m.Name.toLowerCase().startsWith(searchQuery.toLowerCase())
			);
		else if (selectedGenre && selectedGenre._id)
			filtered = info.filter(m => m.category === selectedGenre.name);

		const data = paginateDate(filtered, currentPage, pageSize);

		return { totalCount: filtered.length, data: data };
	};

	render() {
		// const filtered =
		// 	this.state.selectedGenre && this.state.selectedGenre._id
		// 		? this.state.info.filter(
		// 				m => m.category === this.state.selectedGenre.name
		// 		  )
		// 		: this.state.info;

		// const info = paginateDate(
		// 	filtered,
		// 	this.state.currentPage,
		// 	this.state.pageSize
		// );

		const { totalCount, data } = this.getPagedData();

		return (
			<React.Fragment>
				<Navbar />
				<div
					className="container  "
					style={{
						marginLeft: "30%",
						marginBottom: "2%",
						background: ""
					}}
				>
					<div className="row">
						{" "}
						<div className="col-sm-7">
							<Searchbox
								value={this.state.searchQuery}
								onChange={this.handelSearch}
							/>
						</div>
						<div className="col-sm-3" style={{ marginTop: "1%" }}>
							<ListGroup
								items={this.state.genre}
								onItemSelect={this.handleGenreSelect}
								selectedItem={this.state.selectedGenre}
								style={{}}
							/>
						</div>{" "}
					</div>
				</div>

				<div className="row">
					<div className="col-sm-3" style={{ float: "left" }}>
						<NewFiltration></NewFiltration>
					</div>
					<div className="col-sm-9 " style={{}}>
						<GenericCard info={data} onShowClick={this.props.onShowClick} />
					</div>
				</div>
				<div className="d-flex justify-content-center">
					<Pagination
						count={totalCount}
						pageSize={this.state.pageSize}
						onPageChange={this.handlePageChange}
						currentPage={this.state.currentPage}
					/>
				</div>
			</React.Fragment>
		);
	}
}
export default Catalog;
