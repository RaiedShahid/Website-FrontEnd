import React, { Component } from "react";
//import Navbar from './navbar';
//import Calendar from 'react-calendar';

class Signup extends Component {
	render() {
		return (
			<React.Fragment>
				<div className="login">
					<div
						style={{
							backgroundColor: "white",
							marginTop: "10%",
							marginBottom: "10%"
						}}
					>
						<h1>Signup</h1>
					</div>
					<div className="login_inner">
						<form action="/action_page.php">
							<div className="form-group">
								<label>First Name:</label>
								<input
									type="f_name"
									className="form-control"
									id="f_name"
								></input>
							</div>
							<div className="form-group">
								<label>Last Name:</label>
								<input
									type="l_name"
									className="form-control"
									id="l_name"
								></input>
							</div>
							<div className="form-group">
								<label>Email address:</label>
								<input type="email" className="form-control" id="email"></input>
							</div>
							<div className="form-group">
								<label htmlFor="pwd">Password:</label>
								<input
									type="password"
									className="form-control"
									id="pwd"
								></input>
							</div>
							<div className="form-group">
								<label htmlFor="cpwd">Confirm Password:</label>
								<input
									type="password"
									className="form-control"
									id="cpwd"
								></input>
							</div>
							<div className="checkbox">
								<label>
									<input type="checkbox"></input> Remember me
								</label>
							</div>
							<button type="submit" className="btn btn-primary">
								SignUp
							</button>
						</form>
					</div>
				</div>
			</React.Fragment>
		);
	}
}
export default Signup;
