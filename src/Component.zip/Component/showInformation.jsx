import React from "react";
import Navbar from "./navbar";
import Footer from "./footer";

const ShowInformation = ({ match }) => {
	return (
		<React.Fragment>
			<Navbar />
			<h2>{match.params.object}</h2>

			<Footer />
		</React.Fragment>
	);
};

export default ShowInformation;
