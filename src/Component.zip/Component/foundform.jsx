import React, { Component } from "react";
import Navbar from "./navbar";
import Calendar from "react-calendar";

class Foundform extends Component {
	state = {
		date: new Date()
	};

	onChange = date => this.setState({ date });
	render() {
		return (
			<found>
				<Navbar />

				<div className="lost">
					<div style={{ backgroundColor: "white" }}>
						<h1 style={{ marginLeft: "46%" }}>Found Form</h1>
					</div>
					<form>
						<div class="form-group">
							<h4 style={{ backgroundColor: "" }}>Found Person Information</h4>
							<div
								style={{
									backgroundColor: "red",
									float: "right",
									height: 100,
									width: 100
								}}
							></div>
							<div style={{ width: 700, marginLeft: 20 }}>
								<label style={{ fontWeight: "bold" }}> Full Name</label>
								<input
									type="name"
									class="form-control"
									id="p_name"
									placeholder="Full Name"
								></input>
								<label style={{ fontWeight: "bold" }}>Age</label>
								<input
									type="age"
									class="form-control"
									id="p_age"
									placeholder="Age"
								></input>
							</div>
							<hr />
							<div style={{ marginTop: 20 }}>
								<h4 style={{ backgroundColor: "" }}>Found Details</h4>
								<div style={{ width: 700, marginLeft: 20 }}>
									<label style={{ fontWeight: "bold" }}>Date</label>
									<Calendar onChange={this.onChange} value={this.state.date} />
									<div style={{ marginTop: 20 }}>
										<div style={{ float: "left" }}>
											<label style={{ fontWeight: "bold" }}>Province</label>
											<select class="form-control" id="l_province">
												<option>Punjab</option>
												<option>Sindth</option>
												<option>Balochistan</option>
												<option>Khyber Pakhtunkhwa</option>
											</select>
										</div>

										<div style={{ float: "left", marginLeft: 20 }}>
											<label style={{ fontWeight: "bold" }}>City</label>
											<select class="form-control" id="l_city">
												<option>Lahore</option>
												<option>Karachi</option>
												<option>Quetta</option>
												<option>Peshawar</option>
											</select>
										</div>

										<div style={{ float: "left", marginLeft: 20 }}>
											<label style={{ fontWeight: "bold" }}>Area</label>
											<select class="form-control" id="l_area">
												<option>Lahore</option>
												<option>Karachi</option>
												<option>Quetta</option>
												<option>Peshawar</option>
											</select>
										</div>
									</div>
									<div style={{ marginTop: 120 }}>
										<label style={{ fontWeight: "bold" }}>Other Details</label>
										<textarea
											class="form-control"
											id="p_other_details"
											rows="3"
										></textarea>
									</div>
								</div>
							</div>
							<hr />
							<div style={{ width: 700, marginTop: 20 }}>
								<h4 style={{ backgroundColor: "" }}>Contact Information</h4>
								<div style={{ width: 700, marginLeft: 20 }}>
									<label style={{ fontWeight: "bold" }}> Full Name</label>
									<input
										type="name"
										class="form-control"
										id="p_name"
										placeholder="Full Name"
									></input>
									<label style={{ fontWeight: "bold" }}>Contact Number</label>
									<input
										type="contact"
										class="form-control"
										id="p_Contact"
										placeholder="Contact Number"
									></input>
									<label style={{ fontWeight: "bold" }}>Address</label>
									<textarea
										class="form-control"
										id="p_Address"
										rows="3"
									></textarea>
								</div>
							</div>
						</div>
						<button type="submit" class="btn btn-primary">
							Submit
						</button>
					</form>
				</div>
				<div class="footer"></div>
			</found>
		);
	}
}
export default Foundform;
