import React, { Component } from "react";
import prsn from "../images/person.png";
import { Link } from "react-router-dom";

const GenericCard = props => {
	const { info, onShowClick } = props;
	return info.map(each => (
		<div
			key={each.id}
			className="card col-md-4 col-sm-5"
			style={{
				//width: "50%",
				width: "18rem",
				float: "left",
				marginLeft: "2%",
				marginRight: "1%",
				marginBottom: "2%"
			}}
		>
			<img
				className="card-img-top"
				src={prsn}
				alt="Card image"
				style={{ width: "100%" }}
			/>
			<div className="card-body">
				<h4 className="card-title">{each.Name}</h4>
				<h4
					className={
						each.category === "lost"
							? " btn btn-danger btn-sm disabled "
							: "btn btn-warning btn-sm disabled "
					}
					style={{
						cursor: "auto",
						background: "",
						color: "white",
						float: "right"
					}}
				>
					{each.category}
				</h4>
				<p className="card-text">
					Age :<b> {each.Age}</b>{" "}
				</p>
				<p className="card-text">
					City :<b> {each.city}</b>{" "}
				</p>
				{/* <p className="card-text">
                    Some example text some example text. John Doe is an architect and
                    engineer
                </p> */}
				<Link
					onClick={() => onShowClick(each)}
					to={`/home/${each.Name}${each.city}${each.Age} `}
					className="btn btn-success"
				>
					Show
				</Link>
			</div>
		</div>
	));
};

export default GenericCard;
