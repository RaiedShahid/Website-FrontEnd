import React, { Component } from "react";
import ltnfd from "../images/lost-and-found.jpg";
import { Link } from "react-router-dom";

class Navbar extends Component {
	render() {
		return (
			<nav className="navbar navbar-expand-md bg-light navbar-light">
				<div className="row">
					<img src={ltnfd} style={{ width: "5%" }} alt="" />
					<div className="col-sm-3">
						{" "}
						<Link className="navbar-brand" to="/">
							<b>Lost&Found</b>
						</Link>
					</div>
					<div className="col-sm-6" style={{ marginRight: "" }}>
						{" "}
						{/* <div className="active-pink-3 mb-1">
							<input
								className="form-control"
								type="text"
								placeholder="Search"
								aria-label="Search"
							/>
						</div> */}
					</div>
					<div className="col-sm-2" style={{ marginRight: "0" }}>
						{" "}
						<button
							className="navbar-toggler"
							type="button"
							data-toggle="collapse"
							data-target="#collapsibleNavbar"
						>
							<span className="navbar-toggler-icon"></span>
						</button>
						<div className="collapse navbar-collapse" id="collapsibleNavbar">
							<ul className="navbar-nav">
								<li className="nav-item">
									<Link className="nav-link" to="/">
										Home
									</Link>
								</li>
								<li className="nav-item">
									<Link
										className="nav-link btn btn-success"
										style={{ color: "White" }}
										to="/postAdd"
									>
										PostAd
									</Link>
								</li>
								<li className="nav-item">
									<Link
										className="nav-link"
										style={{ color: "green" }}
										to="/login page"
									>
										<b> LOGIN</b>
									</Link>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</nav>
		);
	}
}

export default Navbar;
